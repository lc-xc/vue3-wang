// 物品类
// 物品类
export default {
  install(app, options) {
    class Goods {
      constructor(public name: string, public price: number) {}

      getInfo() {
        return `${this.name}的价格是${this.price}元`;
      }
    }

    app.config.globalProperties.$goods = Goods;
  }
};
