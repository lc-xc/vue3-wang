<script setup>
import Header
</script>

<template>
  <div class="common-layout">
    <el-container>
      <el-header class="common-layout-header">Header</el-header>
      <el-container class="common-layout-other">
        <el-aside width="200px">Aside</el-aside>
        <el-main>Main</el-main>
      </el-container>
    </el-container>
  </div>
  <!-- <a href="https://element-plus.org/zh-CN/guide/design.html"/> -->
</template>
<style lang="scss" scoped>
$--header-height: 90px;
.common-layout {
  width: 100vw;
  height: 100vh;
}
.common-layout-header {
  height: $--header-height;
}
.common-layout-other {
  height: calc(100vh - $--header-height);
}
</style>
