<script setup>
import { onMounted } from 'vue';
onMounted(() => {
});
</script>
<template>
<div class="work-area">
  asdf
</div>
</template>
<style lang="scss" scoped>
.work-area {
  flex: 1;
}
</style>
